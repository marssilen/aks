<?php
class Cat extends Controller
{
	function index($cat=0,$page=1){
	    $items=$this->formModel->getCatItems($cat,$page);
        $this->view('cat/index',['items'=>$items,'pview'=>$this->formModel->get_pview($cat,$page),'cat'=>$cat]);
	}

}
