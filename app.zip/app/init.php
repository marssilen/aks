<?php
//echo 'vak';

//core
require_once 'core/App.php';
require_once 'core/Controller.php';
require_once 'core/ControllerPanel.php';
require_once 'core/Model.php';
//config
require_once 'config/path.php';
//lib
require_once 'libs/database.php';
require_once 'libs/session.php';
require_once 'libs/form.php';
require_once 'libs/functions.php';
require_once('libs/Upload.php');
