<?php
class About extends Controller
{
	function __construct(){

	}
	function index(){
		
	}
}
