<?php
define('URL','http://localhost/aks/');
//define('URL','http://192.168.1.3/aks/');
define('LINK','javascript:void(0)');
define('LOGIN','onclick="document.getElementById(\'login_modal\').style.display=\'block\'"');
