<div id="footer" class="" style="margin-top:20px;margin-bottom: 0px;background-color: silver;text-align: center;padding-top:25px">
    ما را در دنبال کنید:
    <br>
    <a href="#" class="fa fa-instagram"></a>
    <!--    Instagram-->
    <a href="#" class="fa fa-facebook"></a>
    <!--    Facebook-->
    <a href="#" class="fa fa-twitter"></a>
    <!--    Twitter-->
    <a href="#" class="fa fa-telegram"></a>
    <!--    Telegram-->
</div>